public static void main(String[] args) {

        Endereco endereco = new Endereco();
        endereco.setRua("Sete de Abril");
        endereco.setCidade("Floripa");
        endereco.setUf(309);
        endereco.setCep("3230093");
        endereco.setPais("Brasil");
        //System.out.println(endereco);

        Pessoal pessoal = new Pessoal();
        pessoal.setNome("Pedro Gabriel");
        pessoal.setTelefone("320215");
        pessoal.setEmail("Rua dos Ceus");
        //System.out.println(pessoal);

        Aluno aluno = new Aluno();
        aluno.setMatricula("234");
        aluno.setMedia("9");
        //System.out.println(aluno);

        Professor professor = new Pessoal();
        professor.setSalario("1.200");
        //System.out.println(pessoal);


